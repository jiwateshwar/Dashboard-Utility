import { useEffect, useMemo, useState } from "react";
import { api } from "../api";

export default function AdminPage() {
  const [tab, setTab] = useState<"users" | "dashboards" | "groups" | "teams" | "accounts" | "categories" | "access" | "signup-requests" | "access-requests" | "delete-requests">("users");
  const [me, setMe] = useState<any>(null);
  const [signupRequests, setSignupRequests] = useState<any[]>([]);
  const [accessRequests, setAccessRequests] = useState<any[]>([]);
  const [deleteRequests, setDeleteRequests] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [dashboards, setDashboards] = useState<any[]>([]);
  const [groups, setGroups] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [pendingAccounts, setPendingAccounts] = useState<any[]>([]);
  const [renamingAccountId, setRenamingAccountId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [categories, setCategories] = useState<any[]>([]);
  const [accountDashboard, setAccountDashboard] = useState<string>("");
  const [categoryDashboard, setCategoryDashboard] = useState<string>("");
  const [error, setError] = useState<string | null>(null);

  // Group management
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [groupDashboards, setGroupDashboards] = useState<any[]>([]);
  const [groupDashboardsLoading, setGroupDashboardsLoading] = useState(false);

  // Team management (Links sharing groups)
  const [teams, setTeams] = useState<any[]>([]);
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
  const [teamMembers, setTeamMembers] = useState<any[]>([]);
  const [teamMembersLoading, setTeamMembersLoading] = useState(false);
  const [newTeam, setNewTeam] = useState({ name: "", description: "" });

  const [newUser, setNewUser] = useState({ name: "", email: "", manager_id: "", role: "User" });
  const [editingUser, setEditingUser] = useState<{ id: string; name: string; email: string; manager_id: string; role: string; is_active: boolean } | null>(null);
  const [newDashboard, setNewDashboard] = useState({ name: "", description: "", owner_ids: [] as string[], parent_dashboard_id: "" });
  const [editingDashboard, setEditingDashboard] = useState<{ id: string; name: string; description: string; ownerIds: string[]; parent_dashboard_id: string } | null>(null);
  const [newGroup, setNewGroup] = useState({ name: "", description: "" });
  const [groupAssign, setGroupAssign] = useState({ dashboard_id: "", group_id: "" });
  const [newAccount, setNewAccount] = useState({ account_name: "", account_type: "", region: "" });
  const [newCategory, setNewCategory] = useState({ name: "" });
  const [accessGrant, setAccessGrant] = useState({ dashboard_id: "", target_user_id: "", can_view: true, can_edit: false });
  const [accessList, setAccessList] = useState<any[]>([]);

  async function loadAll() {
    setError(null);
    try {
      const results = await Promise.allSettled([
        api("/users"), api("/dashboards"), api("/groups"),
        api("/accounts"), api("/admin/signup-requests"), api("/dashboards/access-requests"),
        api("/accounts/pending"), api("/auth/me"), api("/dashboards/delete-requests"),
        api("/share-teams")
      ]);
      if (results[0].status === "fulfilled") setUsers(results[0].value as any[]);
      if (results[1].status === "fulfilled") setDashboards(results[1].value as any[]);
      if (results[2].status === "fulfilled") setGroups(results[2].value as any[]);
      if (results[3].status === "fulfilled") setAccounts(results[3].value as any[]);
      if (results[4].status === "fulfilled") setSignupRequests(results[4].value as any[]);
      if (results[5].status === "fulfilled") setAccessRequests(results[5].value as any[]);
      if (results[6].status === "fulfilled") setPendingAccounts(results[6].value as any[]);
      if (results[7].status === "fulfilled") setMe(results[7].value);
      if (results[8].status === "fulfilled") setDeleteRequests(results[8].value as any[]);
      if (results[9].status === "fulfilled") setTeams(results[9].value as any[]);
    } catch (err: any) { setError(err.message || "Failed to load data"); }
  }

  useEffect(() => { loadAll(); }, []);

  useEffect(() => {
    if (!selectedGroupId) { setGroupDashboards([]); return; }
    setGroupDashboardsLoading(true);
    api(`/groups/${selectedGroupId}/dashboards`)
      .then(setGroupDashboards)
      .catch(() => setGroupDashboards([]))
      .finally(() => setGroupDashboardsLoading(false));
  }, [selectedGroupId]);

  useEffect(() => {
    if (!selectedTeamId) { setTeamMembers([]); return; }
    setTeamMembersLoading(true);
    api(`/share-teams/${selectedTeamId}/members`)
      .then(setTeamMembers)
      .catch(() => setTeamMembers([]))
      .finally(() => setTeamMembersLoading(false));
  }, [selectedTeamId]);

  useEffect(() => {
    if (!categoryDashboard) { setCategories([]); return; }
    api(`/categories?dashboard_id=${categoryDashboard}`).then(setCategories).catch(() => setCategories([]));
  }, [categoryDashboard]);

  useEffect(() => {
    if (!accessGrant.dashboard_id) { setAccessList([]); return; }
    api(`/dashboards/${accessGrant.dashboard_id}/access`).then(setAccessList).catch(() => setAccessList([]));
  }, [accessGrant.dashboard_id]);

  const dashboardOptions = useMemo(() => dashboards, [dashboards]);

  // ── Owner chip helpers ──────────────────────────────────────

  function addOwnerToNew(uid: string) {
    if (!uid || newDashboard.owner_ids.includes(uid)) return;
    setNewDashboard({ ...newDashboard, owner_ids: [...newDashboard.owner_ids, uid] });
  }
  function removeOwnerFromNew(uid: string) {
    setNewDashboard({ ...newDashboard, owner_ids: newDashboard.owner_ids.filter((id) => id !== uid) });
  }
  function addOwnerToEdit(uid: string) {
    if (!editingDashboard || !uid || editingDashboard.ownerIds.includes(uid)) return;
    setEditingDashboard({ ...editingDashboard, ownerIds: [...editingDashboard.ownerIds, uid] });
  }
  function removeOwnerFromEdit(uid: string) {
    if (!editingDashboard) return;
    setEditingDashboard({ ...editingDashboard, ownerIds: editingDashboard.ownerIds.filter((id) => id !== uid) });
  }

  function OwnerChips({ ownerIds, onRemove }: { ownerIds: string[]; onRemove: (uid: string) => void }) {
    return (
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6, minHeight: 32, alignItems: "center" }}>
        {ownerIds.length === 0 && <span style={{ fontSize: 12, color: "var(--muted)" }}>No owners added yet</span>}
        {ownerIds.map((uid) => {
          const u = users.find((x) => x.id === uid);
          return (
            <span key={uid} style={{ display: "inline-flex", alignItems: "center", gap: 4, background: "#eef6ff", color: "#1d63ed", borderRadius: 999, padding: "3px 10px", fontSize: 12, fontWeight: 500 }}>
              {u?.name ?? uid}
              <button onClick={() => onRemove(uid)} style={{ background: "none", border: "none", cursor: "pointer", color: "#1d63ed", padding: 0, lineHeight: 1, fontSize: 14 }}>×</button>
            </span>
          );
        })}
      </div>
    );
  }

  // ── Handlers ────────────────────────────────────────────────

  async function handleCreateUser() {
    setError(null);
    try {
      await api("/users", { method: "POST", body: JSON.stringify({ name: newUser.name, email: newUser.email, manager_id: newUser.manager_id || null, role: newUser.role }) });
      setNewUser({ name: "", email: "", manager_id: "", role: "User" });
      await loadAll();
    } catch (err: any) { setError(err.message); }
  }

  async function handleUpdateUser() {
    if (!editingUser) return;
    setError(null);
    try {
      await api(`/users/${editingUser.id}`, {
        method: "PATCH",
        body: JSON.stringify({ name: editingUser.name, manager_id: editingUser.manager_id || null, role: editingUser.role, is_active: editingUser.is_active })
      });
      setEditingUser(null);
      await loadAll();
    } catch (err: any) { setError(err.message); }
  }

  async function handleCreateDashboard() {
    setError(null);
    if (newDashboard.owner_ids.length === 0) { setError("At least one owner is required"); return; }
    try {
      await api("/dashboards", { method: "POST", body: JSON.stringify({ name: newDashboard.name, description: newDashboard.description, owner_ids: newDashboard.owner_ids, parent_dashboard_id: newDashboard.parent_dashboard_id || null }) });
      setNewDashboard({ name: "", description: "", owner_ids: [], parent_dashboard_id: "" });
      await loadAll();
    } catch (err: any) { setError(err.message); }
  }

  async function handleUpdateDashboard() {
    if (!editingDashboard) return;
    setError(null);
    if (editingDashboard.ownerIds.length === 0) { setError("At least one owner is required"); return; }
    try {
      await api(`/dashboards/${editingDashboard.id}`, { method: "PATCH", body: JSON.stringify({ name: editingDashboard.name, description: editingDashboard.description, parent_dashboard_id: editingDashboard.parent_dashboard_id || null }) });
      await api(`/dashboards/${editingDashboard.id}/owners`, { method: "PUT", body: JSON.stringify({ owner_ids: editingDashboard.ownerIds }) });
      setEditingDashboard(null);
      await loadAll();
    } catch (err: any) { setError(err.message); }
  }

  async function handleToggleDashboardActive(dashboard: any) {
    setError(null);
    try {
      await api(`/dashboards/${dashboard.id}`, { method: "PATCH", body: JSON.stringify({ is_active: !dashboard.is_active }) });
      await loadAll();
    } catch (err: any) { setError(err.message); }
  }

  async function startEditDashboard(d: any) {
    let ownerIds: string[] = [];
    try {
      const owners = await api(`/dashboards/${d.id}/owners`);
      ownerIds = (owners as any[]).map((o: any) => o.user_id);
    } catch {
      ownerIds = d.primary_owner_id ? [d.primary_owner_id] : [];
    }
    setEditingDashboard({ id: d.id, name: d.name, description: d.description || "", ownerIds, parent_dashboard_id: d.parent_dashboard_id || "" });
  }

  async function handleCreateGroup() {
    setError(null);
    try {
      await api("/groups", { method: "POST", body: JSON.stringify(newGroup) });
      setNewGroup({ name: "", description: "" });
      await loadAll();
    } catch (err: any) { setError(err.message); }
  }

  async function handleAssignGroup() {
    setError(null);
    try {
      await api("/groups/assign", { method: "POST", body: JSON.stringify(groupAssign) });
      setGroupAssign({ dashboard_id: "", group_id: "" });
    } catch (err: any) { setError(err.message); }
  }

  async function toggleGroupDashboard(dashboardId: string, currentlyIn: boolean) {
    if (!selectedGroupId) return;
    setError(null);
    try {
      if (currentlyIn) {
        await api(`/groups/${selectedGroupId}/dashboards/${dashboardId}`, { method: "DELETE" });
      } else {
        await api(`/groups/${selectedGroupId}/dashboards`, {
          method: "POST",
          body: JSON.stringify({ dashboard_ids: [dashboardId] })
        });
      }
      const updated = await api(`/groups/${selectedGroupId}/dashboards`);
      setGroupDashboards(updated);
    } catch (err: any) { setError(err.message); }
  }

  async function handleCreateTeam() {
    setError(null);
    try {
      await api("/share-teams", { method: "POST", body: JSON.stringify(newTeam) });
      setNewTeam({ name: "", description: "" });
      await loadAll();
    } catch (err: any) { setError(err.message); }
  }

  async function toggleTeamMember(userId: string, currentlyIn: boolean) {
    if (!selectedTeamId) return;
    setError(null);
    try {
      if (currentlyIn) {
        await api(`/share-teams/${selectedTeamId}/members/${userId}`, { method: "DELETE" });
      } else {
        await api(`/share-teams/${selectedTeamId}/members`, {
          method: "POST",
          body: JSON.stringify({ user_ids: [userId] })
        });
      }
      const updated = await api(`/share-teams/${selectedTeamId}/members`);
      setTeamMembers(updated);
    } catch (err: any) { setError(err.message); }
  }

  async function handleApproveAccessRequest(id: string) {
    setError(null);
    try {
      await api(`/dashboards/access-requests/${id}/approve`, { method: "POST" });
      const updated = await api("/dashboards/access-requests");
      setAccessRequests(updated);
    } catch (err: any) { setError(err.message); }
  }

  async function handleRejectAccessRequest(id: string) {
    setError(null);
    try {
      await api(`/dashboards/access-requests/${id}/reject`, { method: "POST" });
      const updated = await api("/dashboards/access-requests");
      setAccessRequests(updated);
    } catch (err: any) { setError(err.message); }
  }

  async function handleApproveDeleteRequest(id: string) {
    setError(null);
    try {
      await api(`/dashboards/delete-requests/${id}/approve`, { method: "POST" });
      setDeleteRequests((prev) => prev.filter((r) => r.id !== id));
    } catch (err: any) { setError(err.message); }
  }

  async function handleRejectDeleteRequest(id: string) {
    setError(null);
    try {
      await api(`/dashboards/delete-requests/${id}/reject`, { method: "POST" });
      setDeleteRequests((prev) => prev.filter((r) => r.id !== id));
    } catch (err: any) { setError(err.message); }
  }

  async function handleCreateAccount() {
    setError(null);
    try {
      await api("/accounts", { method: "POST", body: JSON.stringify({ ...newAccount, dashboard_id: accountDashboard || null }) });
      setNewAccount({ account_name: "", account_type: "", region: "" });
      const a = await api("/accounts");
      setAccounts(a);
    } catch (err: any) { setError(err.message); }
  }

  async function handleCreateCategory() {
    setError(null);
    if (!categoryDashboard) { setError("Select a dashboard for the category"); return; }
    try {
      await api("/categories", { method: "POST", body: JSON.stringify({ dashboard_id: categoryDashboard, name: newCategory.name }) });
      setNewCategory({ name: "" });
      const c = await api(`/categories?dashboard_id=${categoryDashboard}`);
      setCategories(c);
    } catch (err: any) { setError(err.message); }
  }

  async function toggleAccount(account: any) {
    await api(`/accounts/${account.id}`, { method: "PATCH", body: JSON.stringify({ dashboard_id: accountDashboard || null, is_active: !account.is_active }) });
    const a = await api("/accounts");
    setAccounts(a);
  }

  async function toggleCategory(category: any) {
    if (!categoryDashboard) { setError("Select a dashboard to manage categories"); return; }
    await api(`/categories/${category.id}`, { method: "PATCH", body: JSON.stringify({ dashboard_id: categoryDashboard, is_active: !category.is_active }) });
    const c = await api(`/categories?dashboard_id=${categoryDashboard}`);
    setCategories(c);
  }

  async function handleGrantAccess() {
    setError(null);
    try {
      await api(`/dashboards/${accessGrant.dashboard_id}/access`, { method: "POST", body: JSON.stringify(accessGrant) });
      setAccessGrant((prev) => ({ ...prev, target_user_id: "", can_view: true, can_edit: false }));
      const updated = await api(`/dashboards/${accessGrant.dashboard_id}/access`);
      setAccessList(updated);
    } catch (err: any) { setError(err.message); }
  }

  return (
    <div>
      <h1>Governance Admin</h1>
      {error && <div style={{ color: "#ef6a62", marginBottom: 12 }}>{error}</div>}

      <div className="inline-actions" style={{ marginBottom: 16 }}>
        {(["users", "dashboards", "groups", "teams", "categories", "access"] as const).map((t) => (
          <button key={t} className={`button ${tab === t ? "" : "secondary"}`} onClick={() => setTab(t)} style={{ textTransform: "capitalize" }}>{t}</button>
        ))}
        <button className={`button ${tab === "accounts" ? "" : "secondary"}`} onClick={() => setTab("accounts")}>
          Accounts
          {pendingAccounts.length > 0 && (
            <span style={{ marginLeft: 6, background: "#e53935", color: "#fff", borderRadius: 999, padding: "1px 7px", fontSize: 11, fontWeight: 700 }}>
              {pendingAccounts.length}
            </span>
          )}
        </button>
        <button
          className={`button ${tab === "signup-requests" ? "" : "secondary"}`}
          onClick={() => setTab("signup-requests")}
        >
          Signup Requests
          {signupRequests.filter((r) => r.status === "Pending").length > 0 && (
            <span style={{ marginLeft: 6, background: "#e53935", color: "#fff", borderRadius: 999, padding: "1px 7px", fontSize: 11, fontWeight: 700 }}>
              {signupRequests.filter((r) => r.status === "Pending").length}
            </span>
          )}
        </button>
        <button
          className={`button ${tab === "access-requests" ? "" : "secondary"}`}
          onClick={() => setTab("access-requests")}
        >
          Access Requests
          {accessRequests.length > 0 && (
            <span style={{ marginLeft: 6, background: "#e53935", color: "#fff", borderRadius: 999, padding: "1px 7px", fontSize: 11, fontWeight: 700 }}>
              {accessRequests.length}
            </span>
          )}
        </button>
        {me?.role === "SuperAdmin" && (
          <button
            className={`button ${tab === "delete-requests" ? "" : "secondary"}`}
            onClick={() => setTab("delete-requests")}
          >
            Delete Requests
            {deleteRequests.length > 0 && (
              <span style={{ marginLeft: 6, background: "#e53935", color: "#fff", borderRadius: 999, padding: "1px 7px", fontSize: 11, fontWeight: 700 }}>
                {deleteRequests.length}
              </span>
            )}
          </button>
        )}
      </div>

      {tab === "users" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card">
            <h3 style={{ margin: "0 0 12px 0" }}>Create User</h3>
            <div className="form-row">
              <input className="input" placeholder="Name" value={newUser.name} onChange={(e) => setNewUser({ ...newUser, name: e.target.value })} />
              <input className="input" placeholder="Email" value={newUser.email} onChange={(e) => setNewUser({ ...newUser, email: e.target.value })} />
              <select className="select" value={newUser.manager_id} onChange={(e) => setNewUser({ ...newUser, manager_id: e.target.value })}>
                <option value="">No Manager</option>
                {users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
              </select>
              <select className="select" value={newUser.role} onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}>
                <option value="User">User</option>
                <option value="Admin">Admin</option>
                <option value="SuperAdmin">SuperAdmin</option>
              </select>
            </div>
            <button className="button" onClick={handleCreateUser}>Create User</button>
          </div>

          <div className="card">
            <h3 style={{ margin: "0 0 12px 0" }}>All Users</h3>

            {editingUser && (
              <div className="inline-create-panel" style={{ marginBottom: 16 }}>
                <div style={{ fontWeight: 600, marginBottom: 10, fontSize: 14 }}>Editing: {editingUser.email}</div>
                <div className="form-row">
                  <input className="input" placeholder="Name" value={editingUser.name}
                    onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })} />
                  <select className="select" value={editingUser.manager_id}
                    onChange={(e) => setEditingUser({ ...editingUser, manager_id: e.target.value })}>
                    <option value="">No Manager</option>
                    {users.filter((u) => u.id !== editingUser.id).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
                  </select>
                  <select className="select" value={editingUser.role}
                    onChange={(e) => setEditingUser({ ...editingUser, role: e.target.value })}>
                    <option value="User">User</option>
                    <option value="Admin">Admin</option>
                    <option value="SuperAdmin">SuperAdmin</option>
                  </select>
                  <select className="select" value={editingUser.is_active ? "active" : "inactive"}
                    onChange={(e) => setEditingUser({ ...editingUser, is_active: e.target.value === "active" })}>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
                <div className="inline-actions">
                  <button className="button" onClick={handleUpdateUser}>Save Changes</button>
                  <button className="button secondary" onClick={() => setEditingUser(null)}>Cancel</button>
                </div>
              </div>
            )}

            <table className="table">
              <thead>
                <tr><th>Name</th><th>Email</th><th>Manager</th><th>Role</th><th>Status</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} style={editingUser?.id === u.id ? { background: "#eef6ff" } : {}}>
                    <td style={{ fontWeight: 500 }}>{u.name}</td>
                    <td style={{ color: "var(--muted)" }}>{u.email}</td>
                    <td style={{ color: "var(--muted)" }}>{users.find((m) => m.id === u.manager_id)?.name || "—"}</td>
                    <td>
                      <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 4, fontWeight: 600,
                        background: u.role === "SuperAdmin" ? "rgba(139,92,246,0.12)" : u.role === "Admin" ? "rgba(29,99,237,0.10)" : "rgba(0,0,0,0.06)",
                        color: u.role === "SuperAdmin" ? "#7c3aed" : u.role === "Admin" ? "#1d63ed" : "var(--muted)" }}>
                        {u.role}
                      </span>
                    </td>
                    <td><span className="badge">{u.is_active !== false ? "Active" : "Inactive"}</span></td>
                    <td>
                      <button className="button secondary" style={{ height: 28, padding: "0 10px", fontSize: 12 }}
                        onClick={() => setEditingUser({ id: u.id, name: u.name, email: u.email, manager_id: u.manager_id || "", role: u.role, is_active: u.is_active !== false })}>
                        Edit
                      </button>
                    </td>
                  </tr>
                ))}
                {users.length === 0 && <tr><td colSpan={6} style={{ color: "var(--muted)", textAlign: "center" }}>No users</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "dashboards" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card">
            <h3 style={{ margin: "0 0 12px 0" }}>Create Dashboard</h3>
            <div className="form-row">
              <input className="input" placeholder="Name" value={newDashboard.name} onChange={(e) => setNewDashboard({ ...newDashboard, name: e.target.value })} />
              <input className="input" placeholder="Description" value={newDashboard.description} onChange={(e) => setNewDashboard({ ...newDashboard, description: e.target.value })} />
              <select className="select" value={newDashboard.parent_dashboard_id} onChange={(e) => setNewDashboard({ ...newDashboard, parent_dashboard_id: e.target.value })}>
                <option value="">No Parent (Top Level)</option>
                {dashboards.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
            </div>
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 6 }}>Owners</div>
              <OwnerChips ownerIds={newDashboard.owner_ids} onRemove={removeOwnerFromNew} />
              <select className="select" style={{ marginTop: 8, maxWidth: 260 }} value="" onChange={(e) => addOwnerToNew(e.target.value)}>
                <option value="">+ Add owner…</option>
                {users.filter((u) => !newDashboard.owner_ids.includes(u.id)).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
              </select>
            </div>
            <button className="button" onClick={handleCreateDashboard}>Create Dashboard</button>
          </div>

          <div className="card">
            <h3 style={{ margin: "0 0 12px 0" }}>Existing Dashboards</h3>

            {editingDashboard && (
              <div className="inline-create-panel" style={{ marginBottom: 16 }}>
                <div style={{ fontWeight: 600, marginBottom: 10, fontSize: 14 }}>Editing: {editingDashboard.name}</div>
                <div className="form-row">
                  <input className="input" placeholder="Name" value={editingDashboard.name}
                    onChange={(e) => setEditingDashboard({ ...editingDashboard, name: e.target.value })} />
                  <input className="input" placeholder="Description" value={editingDashboard.description}
                    onChange={(e) => setEditingDashboard({ ...editingDashboard, description: e.target.value })} />
                  <select className="select" value={editingDashboard.parent_dashboard_id}
                    onChange={(e) => setEditingDashboard({ ...editingDashboard, parent_dashboard_id: e.target.value })}>
                    <option value="">No Parent (Top Level)</option>
                    {dashboards.filter((d) => d.id !== editingDashboard.id).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
                  </select>
                </div>
                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 6 }}>Owners</div>
                  <OwnerChips ownerIds={editingDashboard.ownerIds} onRemove={removeOwnerFromEdit} />
                  <select className="select" style={{ marginTop: 8, maxWidth: 260 }} value="" onChange={(e) => addOwnerToEdit(e.target.value)}>
                    <option value="">+ Add owner…</option>
                    {users.filter((u) => !editingDashboard.ownerIds.includes(u.id)).map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
                  </select>
                </div>
                <div className="inline-actions">
                  <button className="button" onClick={handleUpdateDashboard}>Save Changes</button>
                  <button className="button secondary" onClick={() => setEditingDashboard(null)}>Cancel</button>
                </div>
              </div>
            )}

            <table className="table">
              <thead>
                <tr><th>Name</th><th>Parent</th><th>Description</th><th>Owners</th><th>Status</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {dashboards.map((d) => {
                  const owners: any[] = d.owners ?? [];
                  return (
                    <tr key={d.id} style={editingDashboard?.id === d.id ? { background: "#eef6ff" } : {}}>
                      <td style={{ fontWeight: 500 }}>{d.name}</td>
                      <td style={{ color: "var(--muted)" }}>{d.parent_dashboard_name || "—"}</td>
                      <td style={{ color: "var(--muted)" }}>{d.description || "—"}</td>
                      <td>{owners.length > 0 ? owners.map((o: any) => o.name).join(", ") : <span style={{ color: "var(--muted)" }}>—</span>}</td>
                      <td><span className="badge">{d.is_active !== false ? "Active" : "Inactive"}</span></td>
                      <td className="inline-actions">
                        <button className="button secondary" onClick={() => startEditDashboard(d)}>Edit</button>
                        <button className="button secondary" onClick={() => handleToggleDashboardActive(d)}>
                          {d.is_active !== false ? "Deactivate" : "Activate"}
                        </button>
                      </td>
                    </tr>
                  );
                })}
                {dashboards.length === 0 && (
                  <tr><td colSpan={6} style={{ color: "var(--muted)", textAlign: "center" }}>No dashboards</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === "groups" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Create group */}
          <div className="card">
            <h3 style={{ margin: "0 0 12px 0" }}>Create Group</h3>
            <div className="form-row">
              <input className="input" placeholder="Group name" value={newGroup.name} onChange={(e) => setNewGroup({ ...newGroup, name: e.target.value })} />
              <input className="input" placeholder="Description (optional)" value={newGroup.description} onChange={(e) => setNewGroup({ ...newGroup, description: e.target.value })} />
              <button className="button" onClick={handleCreateGroup}>Create</button>
            </div>
          </div>

          {/* Group list + dashboard management */}
          <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 16, alignItems: "start" }}>
            {/* Groups list */}
            <div className="card" style={{ padding: 0, overflow: "hidden" }}>
              <div style={{ padding: "12px 16px", borderBottom: "1px solid var(--border)", fontWeight: 600, fontSize: 13 }}>
                Groups ({groups.length})
              </div>
              {groups.length === 0 ? (
                <div style={{ padding: 16, color: "var(--muted)", fontSize: 13 }}>No groups yet</div>
              ) : (
                groups.map((g) => (
                  <div
                    key={g.id}
                    onClick={() => setSelectedGroupId(g.id === selectedGroupId ? null : g.id)}
                    style={{
                      padding: "10px 16px", cursor: "pointer", borderBottom: "1px solid var(--border)",
                      background: selectedGroupId === g.id ? "rgba(29,99,237,0.08)" : "transparent",
                      borderLeft: selectedGroupId === g.id ? "3px solid #1d63ed" : "3px solid transparent"
                    }}
                  >
                    <div style={{ fontWeight: 500, fontSize: 14 }}>{g.name}</div>
                    {g.description && <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 2 }}>{g.description}</div>}
                  </div>
                ))
              )}
            </div>

            {/* Dashboard membership for selected group */}
            <div className="card">
              {!selectedGroupId ? (
                <div style={{ color: "var(--muted)", fontSize: 13, textAlign: "center", padding: 24 }}>
                  Select a group to manage its dashboards
                </div>
              ) : groupDashboardsLoading ? (
                <div style={{ color: "var(--muted)", fontSize: 13 }}>Loading…</div>
              ) : (
                <>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                    <h3 style={{ margin: 0 }}>
                      {groups.find((g) => g.id === selectedGroupId)?.name} — Dashboards
                    </h3>
                    <span style={{ fontSize: 12, color: "var(--muted)" }}>
                      {groupDashboards.filter((d) => d.in_group).length} of {groupDashboards.length} in group
                    </span>
                  </div>
                  {groupDashboards.length === 0 ? (
                    <div style={{ color: "var(--muted)", fontSize: 13 }}>No dashboards</div>
                  ) : (
                    groupDashboards.map((d) => (
                      <div key={d.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "8px 0", borderTop: "1px solid var(--border)" }}>
                        <input
                          type="checkbox"
                          checked={d.in_group}
                          onChange={() => toggleGroupDashboard(d.id, d.in_group)}
                          style={{ width: 16, height: 16, cursor: "pointer", flexShrink: 0 }}
                        />
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 500, fontSize: 14 }}>{d.name}</div>
                          {d.description && <div style={{ fontSize: 12, color: "var(--muted)" }}>{d.description}</div>}
                        </div>
                        {d.in_group && (
                          <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 4, background: "rgba(46,189,133,0.12)", color: "#2ebd85", fontWeight: 600, flexShrink: 0 }}>
                            In group
                          </span>
                        )}
                      </div>
                    ))
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {tab === "teams" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="card">
            <h3 style={{ margin: "0 0 4px 0" }}>Create Team</h3>
            <p style={{ color: "var(--muted)", fontSize: 13, marginBottom: 12 }}>
              Teams control who links can be shared with — separate from the dashboard-tagging Groups above.
            </p>
            <div className="form-row">
              <input className="input" placeholder="Team name" value={newTeam.name} onChange={(e) => setNewTeam({ ...newTeam, name: e.target.value })} />
              <input className="input" placeholder="Description (optional)" value={newTeam.description} onChange={(e) => setNewTeam({ ...newTeam, description: e.target.value })} />
              <button className="button" onClick={handleCreateTeam}>Create</button>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 16, alignItems: "start" }}>
            <div className="card" style={{ padding: 0, overflow: "hidden" }}>
              <div style={{ padding: "12px 16px", borderBottom: "1px solid var(--border)", fontWeight: 600, fontSize: 13 }}>
                Teams ({teams.length})
              </div>
              {teams.length === 0 ? (
                <div style={{ padding: 16, color: "var(--muted)", fontSize: 13 }}>No teams yet</div>
              ) : (
                teams.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => setSelectedTeamId(t.id === selectedTeamId ? null : t.id)}
                    style={{
                      padding: "10px 16px", cursor: "pointer", borderBottom: "1px solid var(--border)",
                      background: selectedTeamId === t.id ? "rgba(29,99,237,0.08)" : "transparent",
                      borderLeft: selectedTeamId === t.id ? "3px solid #1d63ed" : "3px solid transparent"
                    }}
                  >
                    <div style={{ fontWeight: 500, fontSize: 14 }}>{t.name}</div>
                    {t.description && <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 2 }}>{t.description}</div>}
                    <div style={{ fontSize: 11, color: "var(--muted)", marginTop: 2 }}>{t.member_count} member{t.member_count === 1 ? "" : "s"}</div>
                  </div>
                ))
              )}
            </div>

            <div className="card">
              {!selectedTeamId ? (
                <div style={{ color: "var(--muted)", fontSize: 13, textAlign: "center", padding: 24 }}>
                  Select a team to manage its members
                </div>
              ) : teamMembersLoading ? (
                <div style={{ color: "var(--muted)", fontSize: 13 }}>Loading…</div>
              ) : (
                <>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                    <h3 style={{ margin: 0 }}>
                      {teams.find((t) => t.id === selectedTeamId)?.name} — Members
                    </h3>
                    <span style={{ fontSize: 12, color: "var(--muted)" }}>
                      {teamMembers.filter((m) => m.in_team).length} of {teamMembers.length} in team
                    </span>
                  </div>
                  {teamMembers.length === 0 ? (
                    <div style={{ color: "var(--muted)", fontSize: 13 }}>No users</div>
                  ) : (
                    teamMembers.map((m) => (
                      <div key={m.user_id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "8px 0", borderTop: "1px solid var(--border)" }}>
                        <input
                          type="checkbox"
                          checked={m.in_team}
                          onChange={() => toggleTeamMember(m.user_id, m.in_team)}
                          style={{ width: 16, height: 16, cursor: "pointer", flexShrink: 0 }}
                        />
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 500, fontSize: 14 }}>{m.name}</div>
                          <div style={{ fontSize: 12, color: "var(--muted)" }}>{m.email}</div>
                        </div>
                        {m.in_team && (
                          <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 4, background: "rgba(46,189,133,0.12)", color: "#2ebd85", fontWeight: 600, flexShrink: 0 }}>
                            Member
                          </span>
                        )}
                      </div>
                    ))
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {tab === "accounts" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        {pendingAccounts.length > 0 && (
          <div className="card">
            <h3 style={{ margin: "0 0 12px 0" }}>
              Pending Account Requests
              <span style={{ marginLeft: 8, background: "#e53935", color: "#fff", borderRadius: 999, padding: "1px 8px", fontSize: 12, fontWeight: 700 }}>
                {pendingAccounts.length}
              </span>
            </h3>
            <table className="table">
              <thead>
                <tr><th>Proposed Name</th><th>Proposed By</th><th>Submitted</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {pendingAccounts.map((a) => (
                  <tr key={a.id}>
                    <td style={{ fontWeight: 500 }}>{a.account_name}</td>
                    <td style={{ color: "var(--muted)" }}>{a.proposed_by_name || "—"}</td>
                    <td style={{ color: "var(--muted)", fontSize: 13 }}>{new Date(a.created_at).toLocaleString()}</td>
                    <td>
                      {renamingAccountId === a.id ? (
                        <div className="inline-actions">
                          <input
                            className="input"
                            value={renameValue}
                            onChange={(e) => setRenameValue(e.target.value)}
                            placeholder="New name"
                            style={{ maxWidth: 180, height: 28, padding: "0 8px", fontSize: 13 }}
                          />
                          <button className="button" style={{ height: 28, padding: "0 12px", fontSize: 12 }}
                            onClick={async () => {
                              try {
                                await api(`/accounts/${a.id}/approve`, { method: "POST", body: JSON.stringify({ account_name: renameValue.trim() || undefined }) });
                                setRenamingAccountId(null); setRenameValue("");
                                const [all, pending] = await Promise.all([api("/accounts"), api("/accounts/pending")]);
                                setAccounts(all as any[]); setPendingAccounts(pending as any[]);
                              } catch (e: any) { setError(e.message); }
                            }}>
                            Approve with Rename
                          </button>
                          <button className="button secondary" style={{ height: 28, padding: "0 10px", fontSize: 12 }}
                            onClick={() => { setRenamingAccountId(null); setRenameValue(""); }}>
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <div className="inline-actions">
                          <button className="button" style={{ height: 28, padding: "0 12px", fontSize: 12 }}
                            onClick={async () => {
                              try {
                                await api(`/accounts/${a.id}/approve`, { method: "POST", body: JSON.stringify({}) });
                                const [all, pending] = await Promise.all([api("/accounts"), api("/accounts/pending")]);
                                setAccounts(all as any[]); setPendingAccounts(pending as any[]);
                              } catch (e: any) { setError(e.message); }
                            }}>
                            Accept
                          </button>
                          <button className="button secondary" style={{ height: 28, padding: "0 10px", fontSize: 12 }}
                            onClick={() => { setRenamingAccountId(a.id); setRenameValue(a.account_name); }}>
                            Rename &amp; Accept
                          </button>
                          <button className="button danger" style={{ height: 28, padding: "0 10px", fontSize: 12 }}
                            onClick={async () => {
                              if (!confirm(`Reject "${a.account_name}"? Tasks using this account will remain but the account will be deactivated.`)) return;
                              try {
                                await api(`/accounts/${a.id}/reject`, { method: "POST", body: JSON.stringify({}) });
                                const [all, pending] = await Promise.all([api("/accounts"), api("/accounts/pending")]);
                                setAccounts(all as any[]); setPendingAccounts(pending as any[]);
                              } catch (e: any) { setError(e.message); }
                            }}>
                            Reject
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="card">
          <h3>Accounts (Admin/Owner)</h3>
          <div className="form-row">
            <input className="input" placeholder="Account name" value={newAccount.account_name} onChange={(e) => setNewAccount({ ...newAccount, account_name: e.target.value })} />
            <input className="input" placeholder="Type" value={newAccount.account_type} onChange={(e) => setNewAccount({ ...newAccount, account_type: e.target.value })} />
            <input className="input" placeholder="Region" value={newAccount.region} onChange={(e) => setNewAccount({ ...newAccount, region: e.target.value })} />
            <select className="select" value={accountDashboard} onChange={(e) => setAccountDashboard(e.target.value)}>
              <option value="">Dashboard (optional)</option>
              {dashboardOptions.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          <button className="button" onClick={handleCreateAccount}>Create Account</button>
          <table className="table" style={{ marginTop: 12 }}>
            <thead><tr><th>Name</th><th>Type</th><th>Region</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              {accounts.filter((a) => !a.is_pending).map((a) => (
                <tr key={a.id}>
                  <td>{a.account_name}</td><td>{a.account_type || "-"}</td><td>{a.region || "-"}</td>
                  <td><span className="badge">{a.is_active ? "Active" : "Inactive"}</span></td>
                  <td><button className="button" onClick={() => toggleAccount(a)}>{a.is_active ? "Deactivate" : "Activate"}</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        </div>
      )}

      {tab === "categories" && (
        <div className="card">
          <h3>Categories (Owner)</h3>
          <div className="form-row">
            <select className="select" value={categoryDashboard} onChange={(e) => setCategoryDashboard(e.target.value)}>
              <option value="">Dashboard</option>
              {dashboardOptions.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
            <input className="input" placeholder="Category name" value={newCategory.name} onChange={(e) => setNewCategory({ name: e.target.value })} />
          </div>
          <button className="button" onClick={handleCreateCategory}>Create Category</button>
          <table className="table" style={{ marginTop: 12 }}>
            <thead><tr><th>Name</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              {categories.map((c) => (
                <tr key={c.id}>
                  <td>{c.name}</td>
                  <td><span className="badge">{c.is_active ? "Active" : "Inactive"}</span></td>
                  <td><button className="button" onClick={() => toggleCategory(c)}>{c.is_active ? "Deactivate" : "Activate"}</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "signup-requests" && (
        <div className="card">
          <h3 style={{ margin: "0 0 16px 0" }}>Signup Requests</h3>
          <table className="table">
            <thead>
              <tr><th>Name</th><th>Email</th><th>Manager</th><th>Source</th><th>Requested</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {signupRequests.length === 0 && (
                <tr><td colSpan={7} style={{ color: "var(--muted)", textAlign: "center" }}>No signup requests</td></tr>
              )}
              {signupRequests.map((r) => (
                <tr key={r.id}>
                  <td style={{ fontWeight: 500 }}>{r.name}</td>
                  <td style={{ color: "var(--muted)" }}>{r.email}</td>
                  <td style={{ color: "var(--muted)" }}>{r.manager_name || "—"}</td>
                  <td style={{ color: "var(--muted)", fontSize: 13 }}>{r.via_sso ? "Microsoft SSO" : "Manual"}</td>
                  <td style={{ color: "var(--muted)", fontSize: 13 }}>{new Date(r.requested_at).toLocaleString()}</td>
                  <td>
                    <span style={{
                      padding: "2px 10px", borderRadius: 999, fontSize: 12, fontWeight: 600,
                      background: r.status === "Pending" ? "rgba(245,166,35,0.15)" : r.status === "Approved" ? "rgba(34,197,94,0.15)" : "rgba(239,106,98,0.15)",
                      color: r.status === "Pending" ? "#b45309" : r.status === "Approved" ? "#15803d" : "#ef6a62"
                    }}>{r.status}</span>
                  </td>
                  <td>
                    {r.status === "Pending" ? (
                      <div className="inline-actions">
                        <button className="button" style={{ height: 28, padding: "0 12px", fontSize: 12 }}
                          onClick={async () => {
                            try {
                              await api(`/admin/signup-requests/${r.id}/approve`, { method: "POST" });
                              await loadAll();
                            } catch (e: any) { setError(e.message); }
                          }}>
                          Approve
                        </button>
                        <button className="button secondary" style={{ height: 28, padding: "0 12px", fontSize: 12 }}
                          onClick={async () => {
                            try {
                              await api(`/admin/signup-requests/${r.id}/reject`, { method: "POST" });
                              await loadAll();
                            } catch (e: any) { setError(e.message); }
                          }}>
                          Reject
                        </button>
                      </div>
                    ) : (
                      <span style={{ fontSize: 12, color: "var(--muted)" }}>by {r.reviewed_by_name || "—"}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "access-requests" && (
        <div className="card">
          <h3 style={{ margin: "0 0 16px 0" }}>Dashboard Access Requests</h3>
          <table className="table">
            <thead>
              <tr><th>Dashboard</th><th>User</th><th>Email</th><th>Requested</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {accessRequests.length === 0 && (
                <tr><td colSpan={5} style={{ color: "var(--muted)", textAlign: "center" }}>No pending access requests</td></tr>
              )}
              {accessRequests.map((r) => (
                <tr key={r.id}>
                  <td style={{ fontWeight: 500 }}>{r.dashboard_name}</td>
                  <td>{r.user_name}</td>
                  <td style={{ color: "var(--muted)" }}>{r.user_email}</td>
                  <td style={{ color: "var(--muted)", fontSize: 13 }}>{new Date(r.created_at).toLocaleString()}</td>
                  <td>
                    <div className="inline-actions">
                      <button className="button" style={{ height: 28, padding: "0 12px", fontSize: 12 }}
                        onClick={() => handleApproveAccessRequest(r.id)}>
                        Approve
                      </button>
                      <button className="button secondary" style={{ height: 28, padding: "0 12px", fontSize: 12 }}
                        onClick={() => handleRejectAccessRequest(r.id)}>
                        Reject
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "delete-requests" && (
        <div className="card">
          <h3 style={{ margin: "0 0 16px 0" }}>Dashboard Deletion Requests</h3>
          <table className="table">
            <thead>
              <tr><th>Dashboard</th><th>Requested By</th><th>Reason</th><th>Requested</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {deleteRequests.length === 0 && (
                <tr><td colSpan={5} style={{ color: "var(--muted)", textAlign: "center" }}>No pending deletion requests</td></tr>
              )}
              {deleteRequests.map((r) => (
                <tr key={r.id}>
                  <td style={{ fontWeight: 500 }}>{r.dashboard_name}</td>
                  <td>{r.requested_by_name}</td>
                  <td style={{ color: "var(--muted)", fontSize: 13 }}>{r.reason || "—"}</td>
                  <td style={{ color: "var(--muted)", fontSize: 13 }}>{new Date(r.created_at).toLocaleString()}</td>
                  <td>
                    <div className="inline-actions">
                      <button className="button danger" style={{ height: 28, padding: "0 12px", fontSize: 12 }}
                        onClick={() => handleApproveDeleteRequest(r.id)}>
                        Approve &amp; Deactivate
                      </button>
                      <button className="button secondary" style={{ height: 28, padding: "0 12px", fontSize: 12 }}
                        onClick={() => handleRejectDeleteRequest(r.id)}>
                        Reject
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "access" && (
        <div className="card">
          <h3>Dashboard Access (Owner)</h3>
          <div className="form-row">
            <select className="select" value={accessGrant.dashboard_id} onChange={(e) => setAccessGrant({ ...accessGrant, dashboard_id: e.target.value })}>
              <option value="">Dashboard</option>
              {dashboardOptions.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
            <select className="select" value={accessGrant.target_user_id} onChange={(e) => setAccessGrant({ ...accessGrant, target_user_id: e.target.value })}>
              <option value="">User</option>
              {users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
            <select className="select" value={accessGrant.can_view ? "yes" : "no"} onChange={(e) => setAccessGrant({ ...accessGrant, can_view: e.target.value === "yes" })}>
              <option value="yes">Can View</option><option value="no">No View</option>
            </select>
            <select className="select" value={accessGrant.can_edit ? "yes" : "no"} onChange={(e) => setAccessGrant({ ...accessGrant, can_edit: e.target.value === "yes" })}>
              <option value="no">No Edit</option><option value="yes">Can Edit</option>
            </select>
          </div>
          <button className="button" onClick={handleGrantAccess}>Grant Access</button>
          <table className="table" style={{ marginTop: 12 }}>
            <thead><tr><th>User</th><th>Email</th><th>View</th><th>Edit</th></tr></thead>
            <tbody>
              {accessList.map((a) => (
                <tr key={a.user_id}>
                  <td>{a.name}</td><td>{a.email}</td>
                  <td>{a.can_view ? "Yes" : "No"}</td><td>{a.can_edit ? "Yes" : "No"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
